package com.example.simple_iot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
